<?php
session_start();
include_once 'connection.php';
include_once 'product-action.php';
include_once 'cart.php';

$stmt = $conn->prepare("SELECT * FROM products ORDER BY id ASC");
$stmt->execute();
$products = $stmt->get_result();
echo '<table style="border: 1px solid #ddd;"><tr>';
if (!empty($products)) {
foreach($products as $product){
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/js/bootstrap.bundle.min.js"></script>


  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>



</head>
<body>

</body>
</html>
<div class="card-body">
                        <div class="row justify-content-center">
                            <div class="col-lg-10 col-xl-8">
                                <div class="cart-container">
                                    <div class="cart-head">
                                        <div class="table-responsive">
<td style="border: 1px solid #ddd;">
<form method="post" action="index.php?action=add&id=<?php echo $product['id']; ?>">
<div class="product-image"><img src="images/<?php echo $product['image']; ?>" width="200" height="200"></div>
<div><strong><?php echo $product["product_title"]; ?></strong></div>
<div class="product-price"><?php echo "$".$product["price"]; ?></div>
<div><input type="text" name="quantity" value="1" size="4" />&nbsp;<input type="submit" class="btn btn-info btn-xs" value="Add to cart" /></div>
</form>
</td>
</div>
</div>
</div>
</div>
</div>
</div>

<?php }}

echo '</tr></table>';