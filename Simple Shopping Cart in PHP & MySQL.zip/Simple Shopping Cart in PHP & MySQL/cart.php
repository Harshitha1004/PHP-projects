<?php
if(!empty($_SESSION["cart_item"])){
$item_total = 0;
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	

	<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

</body>
</html>

<a href="index.php?action=empty"><input type="button" class="btn btn-outline-primary" value="Empty Cart"></a>








                                        <div class="table-responsive">
                                            <table class="table table-borderless">
                                                <thead>
                                                    <tr>
                                                    	 <th scope="col">Name</th>                                               
                                                        <th scope="col">Quantity</th>
                                                        <th scope="col">Price</th>
                                                        <th scope="col">Action</th>
                                                       
                                                        
                                                    </tr>
                                                      </thead>
                                                <tbody>
                                                   
                                                       <?php
foreach ($_SESSION["cart_item"] as $item){
?>
<tr>
<td><strong><?php echo $item["product_title"]; ?></strong></td>
<td><?php echo $item["quantity"]; ?></td>
<td><?php echo "$".$item["price"]*$item["quantity"]; ?></td>
<td><a href="index.php?action=remove&id=<?php echo $item["id"]; ?>" class="btnRemoveAction">Remove Item</a></td>
</tr>
<?php
$item_total += ($item["price"]*$item["quantity"]);

}
?>

<tr>
<td colspan="3" align=right><strong>Total:</strong> <?php echo "$".$item_total; ?></td>
</tr>
</tbody>
</table>
<?php
}
?>
                                                       
                                              
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                  
                               
            </div>
            <!-- End col -->
        </div>
        <!-- End row -->
    </div>
    </div>


















